package com.example.btl.mp3player.utils;

/**
 * Created by IceMan on 11/26/2016.
 */

public class Constants {
    public static final String ACTION_COMPLETE_SONG = "com.example.iceman.Mp3Player.ACTION_COMPLETE_SONG";
    public static final String ACTION_SWITCH_SONG = "com.example.iceman.Mp3Player.ACTION_SWITCH_SONG";
    public static final String ACTION_PREV = "com.example.iceman.Mp3Player.ACTION_PREV";
    public static final String ACTION_PLAY_PAUSE = "com.example.iceman.Mp3Player.ACTION_PLAY_PAUSE";
    public static final String ACTION_NEXT = "com.example.iceman.Mp3Player.ACTION_NEXT";
    public static final String ACTION_CHANGE_ALBUM_ART = "com.example.iceman.Mp3Player.ACTION_CHANGE_ALBUM_ART";
    public static final String ACTION_UPDATE_PlAY_STATUS = "com.example.iceman.Mp3Player.ACTION_UPDATE_PlAY_STATUS";
}
